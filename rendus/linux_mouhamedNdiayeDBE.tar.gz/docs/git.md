# Partie 4 — Git/GitHub pratique individuelle (25 points)

Cette partie note les opérations Git réelles et leur historique, pas uniquement le contenu final des fichiers. Le dépôt de référence est `MouhamedNdiayeDBE/dbe-eval-mouhamedNdiayeDBE`.

## G1 — Configuration et signature (2 pts)

À exécuter sur le poste personnel :

```bash
git config --global user.name "Mouhamed Ndiaye"
git config --global user.email "EMAIL_VERIFIE_DANS_GITHUB"
git config --global init.defaultBranch main
git config --global gpg.format ssh
git config --global user.signingkey ~/.ssh/id_ed25519.pub
git config --global commit.gpgsign true
git config --global tag.gpgSign true
ssh-keygen -lf ~/.ssh/id_ed25519.pub
```

Sur GitHub, dans Settings → SSH and GPG keys, la clé publique exacte doit être ajoutée une fois comme Authentication key et une fois comme Signing key. Ne jamais copier la clé privée dans le dépôt.

**État observé :** plusieurs commits personnels et le tag `v1.0` portent bien une signature SSH, mais GitHub répond `verified: false`, raison `no_user`. Les commits initiaux `dc4821e`, `4d4cc05`, `c76632b` et `4ba3b52` sont non signés. Les signatures des commits web-flow sont vérifiées. La configuration de signature n'est donc pas encore validée sur le compte GitHub.

## G2 — Initialiser le dépôt (2 pts)

Le dépôt distant est privé, `main` est la branche par défaut et `.gitignore` contient :

```gitignore
out/
*.class
logs/
```

Les commits initiaux visibles comprennent le code Java (`dc4821e`), les scripts (`4d4cc05`), la documentation (`c76632b`) et les preuves/compléments (`4ba3b52`). L'archive de rendu n'était pas dans ce dernier commit lors de l'audit initial ; elle est maintenant construite sous `rendus/linux_mouhamedNdiayeDBE.tar.gz` dans la branche de correction.

Vérifications locales :

```bash
git status --short
git log --oneline --decorate --all
git check-ignore out/GenerateurLogs.class logs/access.log
```

## G3 — Publier (2 pts)

**État vérifié sur GitHub :** dépôt privé ; branche par défaut `main` ; collaborateur `pape1283` avec permission `write`.

La variable de dépôt `MATRICULE` doit être vérifiée dans Settings → Secrets and variables → Actions → Variables. Le connecteur ne donne pas accès à la valeur ni à la liste de variables Actions ; la valeur utilisée dans `docs/preuves/.bashrc` est `mouhamedNdiayeDBE`. Ne pas transformer cette variable en secret si le workflow utilise `${{ vars.MATRICULE }}`.

## G4 — Intégration continue (4 pts)

Le workflow actif est `.github/workflows/ci.yml` et il se trouve au bon emplacement. Un ancien doublon dans `.github/workflow/ci.yml` a été supprimé dans la PR #2. Le workflow vérifie la variable, la syntaxe Bash, compile Java 17, génère 2 000 lignes, exécute `analyse.sh`, teste l'arrêt SIGTERM et publie le rapport comme artefact.

La PR #1 a été fusionnée, mais les exécutions initiales étaient rouges. La PR #2 (`fix/evaluation-deliverables-ci`) est ouverte. Les runs observés ont échoué avant d'exécuter une étape : job `runner_id: 0`, `steps: []`, aucun log exploitable. Il reste donc à obtenir une exécution verte sur GitHub avant de considérer G4 comme validé.

```bash
git switch -c ci/pipeline
# Le workflow .github/workflows/ci.yml est déjà ajouté dans le dépôt.
git add .github/workflows/ci.yml
git commit -S -m "Ajoute le pipeline CI"
git push -u origin ci/pipeline
```

Sur GitHub : ouvrir une PR vers `main`, attendre le workflow vert, puis fusionner. Le rapport de l'artefact doit correspondre au rapport local.

## G5 — Fonctionnalité, réécriture d'historique et rebase (5 pts)

La fonction `par_heure` est présente dans `scripts/analyse.sh` et le commit `cb9c6b3` l'a ajoutée. Cependant, l'historique actuel contient `wip 1` (`9b71b7a`) et `wip 2` (`bef5ad7`) directement dans l'ascendance de `main`. L'audit n'a pas trouvé de branche `feature/heures` ni de preuve d'un `git rebase -i main`. Le résultat fonctionnel est présent, mais la procédure demandée n'est pas démontrée et l'historique `main` conserve les messages WIP.

La procédure correcte, à effectuer sur une branche de travail avant intégration, est :

```bash
git switch main
git pull --ff-only origin main
git switch -c feature/heures
# Créer les trois commits de travail demandés :
git commit -S -am "wip 1"
git commit -S -am "wip 2"
git commit -S -am "wip 3"
# Ajouter auparavant les modifications requises à chaque étape.
# Ajouter/commiter séparément le README sur main selon le scénario du sujet.
git rebase -i main
# Dans l'éditeur : garder le premier commit en pick, passer les deux autres en squash.
# Remplacer le message final par : Ajoute le regroupement des requêtes par heure.
git switch main
git merge --ff-only feature/heures
git log --oneline --decorate -10
```

**Attention :** ne pas faire de `push --force` sur `main`. Puisque les WIP ont déjà été publiés sur `main`, leur suppression demanderait une réécriture de la branche. Elle n'est pas effectuée par cette correction afin de préserver l'historique distant.

## G6 — Mettre un travail de côté (2 pts)

L'audit des traces `docs/preuves/git.log` n'a pas retrouvé `git stash push`, `git stash list` ni `git stash pop`. Il faut exécuter la séquence dans le dépôt local et coller la vraie sortie dans `docs/git.md` :

```bash
# Modifier README.md sans commiter.
git stash push -m "readme en cours"
git stash list
# Réaliser G7.
git stash pop
git status --short
```

Ne pas inventer une sortie de stash : elle dépend du contenu réel du worktree.

## G7 — Correctif et cherry-pick (2 pts)

Le commit de correction du message d'usage existe sur `main` : `fce7935` (exemple `--top 5`). La branche distante `release/1.0` a maintenant été créée à partir de `cb9c6b3`, parent du commit de correctif `fce7935`. Elle pointe sur `37bc3f5`, un commit dont l'arbre correspond au correctif et dont le message contient le trailer `(cherry picked from commit fce7935...)`. Ce commit équivalent a été construit via l'API GitHub, pas par l'exécution de la commande dans le terminal WSL ; la preuve interactive de `git cherry-pick -x` reste donc à réaliser localement.

Résultat distant créé : `release/1.0` → `37bc3f5` (base `cb9c6b3`, trailer de cherry-pick présent). Pour contrôler ce résultat depuis le poste :

```bash
git fetch origin
git switch release/1.0
git show -1 --format=fuller
```

Séquence de commande demandée par le sujet (l'exécution et l'enregistrement restent à faire dans la session personnelle si l'enseignant exige la preuve de la commande) :

```bash
git switch main
git switch -c release/1.0 HEAD~1
git switch main
# Vérifier que l'exemple --top 5 est présent dans scripts/analyse.sh.
git add scripts/analyse.sh
git commit -S -m "Corrige le message d'usage de analyse.sh (exemple --top 5)"
FIX_SHA=$(git rev-parse HEAD)
git switch release/1.0
git cherry-pick -x "$FIX_SHA"
git show -1 --format=fuller
```

L'opération doit laisser le trailer `cherry picked from commit ...` dans le message du commit reporté. Le correctif existe déjà, mais la preuve de l'exercice reste à produire.

## G8 — Annuler un commit publié (2 pts)

Cette étape est démontrée : le commit `7b26e58` (`Change le top par défaut`) a été annulé par `e38f3f8` (`Revert "Change le top par défaut"`). Le revert conserve l'historique et rétablit le top par défaut à 3. Les deux commits sont visibles sur `main`.

## G9 — Version signée (2 pts)

Le tag signé `v1.0` existe. Son objet contient une signature SSH, mais GitHub indique `verified: false`, raison `no_user`. Il faut enregistrer la clé publique comme Signing key sur GitHub, puis revérifier le tag. L'audit n'a pas trouvé de GitHub Release `v1.0`.

```bash
git tag -v v1.0
git push origin v1.0
```

Puis créer sur GitHub une Release `v1.0` à partir de ce tag et joindre `rendus/linux_${MATRICULE}.tar.gz`. La création d'une Release avec pièce jointe n'est pas disponible via la connexion GitHub utilisée pour cette correction ; elle reste à effectuer dans l'interface GitHub.

## G10 — Preuves (2 pts)

Les enregistrements `docs/preuves/git.log` et `git.tm` existent, mais l'audit n'a pas trouvé de `reflog.txt` ni d'`historique_git.txt`. Les reflogs sont locaux et ne sont pas disponibles à travers le dépôt distant. Sur le PC, à la fin de la session enregistrée :

```bash
git reflog -n 60 > docs/preuves/reflog.txt
history > docs/preuves/historique_git.txt
exit
git add docs && git commit -S -m "Ajoute les preuves de la partie Git"
git push --all
git push --tags
git rev-parse --short HEAD
```

Recopier le SHA court sur la fiche de contrôle. Ne jamais fabriquer `reflog.txt` à partir de `git log` : ce ne sont pas les mêmes informations.

## État au 23 novembre 2026

| Exigence | État vérifié |
|---|---|
| Dépôt privé, `main`, collaborateur `pape1283` | OK |
| `.gitignore`, code Java, scripts | OK |
| README complet et documentation | ajoutés sur la PR #2 |
| Workflow CI au bon emplacement | OK, mais runs rouges avant les étapes |
| `par_heure` dans le rapport | OK |
| Rebase interactif des 3 WIP sur `feature/heures` | non démontré ; WIP déjà sur `main` |
| Stash / stash pop | non démontré |
| Branche `release/1.0` et commit avec trailer cherry-pick | résultat distant présent (`37bc3f5`), commande locale non démontrée |
| Commit de revert de G8 | OK |
| Tag signé `v1.0` | présent, signature non vérifiée par GitHub (`no_user`) |
| Release GitHub avec archive | absente |
| Reflog et historique Bash exportés | absents |

La branche de correction ne réécrit pas `main` et ne prétend pas effectuer les opérations qui nécessitent le shell, la clé SSH privée ou les droits de création de Release de l'étudiant.
